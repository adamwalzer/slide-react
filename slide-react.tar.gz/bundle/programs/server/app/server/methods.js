(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
	addHighScore: function (opts) {                                       // 2
		var sortBy = opts.sort || -1;                                        // 3
		var compare = opts.sort === 1 ? function (s, h) {                    // 4
			return s < h;                                                       // 5
		} : function (s, h) {                                                //
			return s > h;                                                       // 7
		};                                                                   //
		var board = Array(Array(null, null, null, null), Array(null, null, null, null), Array(null, null, null, null), Array(null, null, null, null));
		var highs = HighScores.find({ userId: this.userId, game: opts.game }, { sort: { score: sortBy } }).fetch();
                                                                       //
		for (var i = 0; i < 4; i++) {                                        // 12
			for (var j = 0; j < 4; j++) {                                       // 13
				if (opts.board[i][j]) {                                            // 14
					board[j][i] = opts.board[i][j].v;                                 // 15
				}                                                                  //
			}                                                                   //
		}                                                                    //
                                                                       //
		if (highs.length < 5) {                                              // 20
			HighScores.insert({                                                 // 21
				userId: this.userId,                                               // 22
				game: opts.game,                                                   // 23
				score: opts.score,                                                 // 24
				board: board                                                       // 25
			});                                                                 //
		} else if (highs[4] && highs[4]._id && highs[4].score) {             //
			if (compare(opts.score, highs[4].score)) {                          // 28
				HighScores.update(highs[4]._id, { $set: {                          // 29
						score: opts.score,                                               // 30
						board: board                                                     // 31
					} });                                                             //
			}                                                                   //
		}                                                                    //
	}                                                                     //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=methods.js.map
