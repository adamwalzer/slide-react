(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/bootstrap.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// run this when the meteor app is started                             //
// Meteor.startup(function() {                                         //
// 	// HighScores.remove({});                                          //
// });                                                                 //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=bootstrap.js.map
