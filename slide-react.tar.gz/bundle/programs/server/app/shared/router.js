(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// shared/router.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// Router.configure({                                                  //
// 	layoutTemplate: 'layout',                                          //
// 	onBeforeAction: function() {                                       //
// 		this.next();                                                      //
// 	}                                                                  //
// });                                                                 //
                                                                       //
// Router.route('/', {                                                 //
// 	template: 'appBody'                                                //
// });                                                                 //
                                                                       //
// Router.route('/(.*)', {                                             //
// 	template: 'appBody'                                                //
// });                                                                 //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=router.js.map
